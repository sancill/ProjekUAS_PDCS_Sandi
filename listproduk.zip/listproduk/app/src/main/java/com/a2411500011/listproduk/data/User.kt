package com.a2411500011.listproduk.data

data class User(
    val nama: String,
    val email: String,
    val password: String
)
