# Folder Uploads - Struktur Penyimpanan Assets

Folder ini digunakan untuk menyimpan semua file gambar dan assets yang diupload ke sistem.

## Struktur Folder

```
uploads/
├── produk/      # Gambar produk
├── kategori/    # Icon/gambar kategori
├── toko/        # Logo dan banner toko
└── profiles/    # Foto profil user
```

## Cara Menggunakan

### 1. Upload Gambar Produk
Simpan gambar produk di folder: `uploads/produk/`

**Contoh path di database:**
- `uploads/produk/1765969793_788a7469deb3da6ee246.jpg`
- `uploads/produk/1765998169_dd18dc014ecfef42e5c1.jpg`

### 2. Upload Icon Kategori
Simpan icon kategori di folder: `uploads/kategori/`

**Contoh path di database:**
- `uploads/kategori/1767201352_8c6d7383ecfa76b1e30a.png`

### 3. Upload Logo/Banner Toko
Simpan logo dan banner toko di folder: `uploads/toko/`

**Contoh path di database:**
- `uploads/toko/1766321162_d17760452190e1be7c10.png`
- `uploads/toko/1767465048_e22093c3efc48aa1896c.png`

### 4. Upload Foto Profil
Simpan foto profil user di folder: `uploads/profiles/`

**Contoh path di database:**
- `uploads/profiles/1768228420_7e9a1c043e31f74cbeec.jpg`

## Format File yang Didukung

- **Gambar:** `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`, `.svg`
- **Ukuran maksimal:** Sesuai konfigurasi PHP (biasanya 2MB - 10MB)

## Keamanan

- File `.htaccess` sudah dikonfigurasi untuk mencegah eksekusi file PHP
- Folder ini dapat diakses publik untuk menampilkan gambar
- Pastikan hanya file gambar yang diupload ke folder ini

## Catatan Penting

1. **Path di Database:** Pastikan path yang disimpan di database dimulai dengan `uploads/` (tanpa slash di depan)
2. **Nama File:** Disarankan menggunakan nama file unik (misalnya: timestamp_namafile.jpg) untuk menghindari konflik
3. **Permissions:** Pastikan folder memiliki permission write untuk proses upload
