<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListProduk extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Produk_model');
    }

    /**
     * Display dashboard page
     */
    public function dashboard() {
        $this->load->view('dashboard');
    }

    /**
     * Display product list page
     */
    public function index() {
        $data['produk'] = $this->Produk_model->get_all_produk();
        $this->load->view('list_produk', $data);
    }

    /**
     * AJAX endpoint for search
     */
    public function search() {
        $keyword = $this->input->post('keyword');
        $produk = $this->Produk_model->search_produk($keyword);
        
        header('Content-Type: application/json');
        echo json_encode($produk);
    }
}
