<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "isb_marketplace_1";

$koneksi = mysqli_connect($host, $user, $password, $database);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Set charset untuk mendukung karakter Indonesia
mysqli_set_charset($koneksi, "utf8");
?>
