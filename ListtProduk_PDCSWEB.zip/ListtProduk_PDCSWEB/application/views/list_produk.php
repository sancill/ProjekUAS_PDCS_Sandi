<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Produk</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f9fafb;
            color: #1f2937;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 256px;
            background: white;
            border-right: 1px solid #e5e7eb;
            box-shadow: 0px 4px 6px 0px rgba(0,0,0,0.1), 0px 10px 15px 0px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 24px;
        }

        .sidebar-header h2 {
            font-size: 20px;
            font-weight: bold;
            color: #1f2937;
            letter-spacing: -0.5px;
        }

        .sidebar-nav {
            padding: 0 24px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            margin-bottom: 8px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            color: #374151;
            transition: all 0.2s;
        }

        .nav-item:hover {
            background-color: #f3f4f6;
        }

        .nav-item.active {
            background-color: #2563eb;
            color: white;
        }

        .nav-item svg,
        .nav-item .nav-icon {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            object-fit: contain;
        }

        .nav-item span {
            font-size: 16px;
            letter-spacing: -0.5px;
        }

        /* Main Content */
        .main-content {
            margin-left: 256px;
            flex: 1;
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: white;
            border-bottom: 1px solid #e5e7eb;
            box-shadow: 0px 1px 2px 0px rgba(0,0,0,0.05);
            padding: 16px 32px;
            height: 75px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .header-title {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            letter-spacing: -0.5px;
        }

        .search-container {
            position: relative;
            width: 320px;
        }

        .search-input {
            width: 100%;
            height: 42px;
            padding: 0 16px 0 40px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 16px;
            color: #1f2937;
            outline: none;
            transition: all 0.2s;
            background-color: white;
        }

        .search-input::placeholder {
            color: #adaebc;
        }

        .search-input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            width: 16px;
            height: 16px;
            pointer-events: none;
            color: #6b7280;
        }

        /* Content Area */
        .content-area {
            padding: 32px;
        }

        .page-header {
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }

        .page-description {
            font-size: 16px;
            color: #4b5563;
            letter-spacing: -0.5px;
        }

        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
        }

        .product-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0px 1px 2px 0px rgba(0,0,0,0.05);
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0px 4px 6px 0px rgba(0,0,0,0.1);
        }

        .product-image {
            width: 100%;
            height: 192px;
            object-fit: cover;
            background-color: #f3f4f6;
        }

        .product-info {
            padding: 16px;
        }

        .product-name {
            font-size: 16px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 8px;
            line-height: 24px;
        }

        .product-details {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 8px;
            line-height: 20px;
            min-height: 20px;
        }

        .product-price {
            font-size: 18px;
            font-weight: bold;
            color: #2563eb;
            line-height: 28px;
        }

        .no-products {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
            font-size: 16px;
        }

        @media (max-width: 1400px) {
            .product-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 1024px) {
            .product-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .product-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Menu</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="<?php echo base_url('listproduk/dashboard'); ?>" class="nav-item">
                    <img src="<?php echo base_url('assets/images/icons/home.png'); ?>" alt="Dashboard" class="nav-icon" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <svg viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:none;">
                        <path d="M1 9L9 1L17 9M1 9L9 17L17 9M1 9H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo base_url('listproduk'); ?>" class="nav-item active">
                    <img src="<?php echo base_url('assets/images/icons/clipboard.png'); ?>" alt="List Produk" class="nav-icon" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <svg viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:none;">
                        <path d="M1 1H15M1 5H15M1 9H15M1 13H15M1 17H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    <span>List Produk</span>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1 class="header-title">List Produk</h1>
                <div class="search-container">
                    <svg class="search-icon" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 12C9.76142 12 12 9.76142 12 7C12 4.23858 9.76142 2 7 2C4.23858 2 2 4.23858 2 7C2 9.76142 4.23858 12 7 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M10.5 10.5L14 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <input type="text" id="searchInput" class="search-input" placeholder="Cari produk...">
                </div>
            </div>

            <!-- Content Area -->
            <div class="content-area">
                <div class="page-header">
                    <h2 class="page-title">Daftar Produk</h2>
                    <p class="page-description">Menampilkan semua produk yang tersedia</p>
                </div>

                <!-- Product Grid -->
                <div class="product-grid" id="productGrid">
                    <?php if (!empty($produk)): ?>
                        <?php foreach ($produk as $item): ?>
                            <div class="product-card" data-name="<?php echo strtolower(htmlspecialchars($item['nama_produk'])); ?>">
                                <?php 
                                // Fix image path - remove leading slash if exists and ensure proper path
                                $gambar_path = !empty($item['gambar']) ? trim($item['gambar'], '/') : '';
                                $image_url = !empty($gambar_path) ? base_url($gambar_path) : '';
                                
                                // Debug: uncomment to see the path
                                // echo '<!-- Image path: ' . $gambar_path . ' -->';
                                // echo '<!-- Full URL: ' . $image_url . ' -->';
                                ?>
                                <img src="<?php echo $image_url; ?>" 
                                     alt="<?php echo htmlspecialchars($item['nama_produk']); ?>" 
                                     class="product-image"
                                     onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'260\' height=\'192\'%3E%3Crect fill=\'%23f3f4f6\' width=\'260\' height=\'192\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' text-anchor=\'middle\' dy=\'.3em\' fill=\'%239ca3af\' font-family=\'sans-serif\' font-size=\'14\'%3ENo Image%3C/text%3E%3C/svg%3E';">
                                <div class="product-info">
                                    <h3 class="product-name"><?php echo htmlspecialchars($item['nama_produk']); ?></h3>
                                    <p class="product-details">
                                        <?php 
                                        if (!empty($item['varian']) && count($item['varian']) > 0) {
                                            $varian_text = array();
                                            foreach ($item['varian'] as $varian) {
                                                $varian_text[] = $varian['nama_varian'] . ': ' . $varian['nilai_varian'];
                                            }
                                            echo htmlspecialchars(implode(', ', $varian_text));
                                        } else {
                                            echo '&nbsp;';
                                        }
                                        ?>
                                    </p>
                                    <p class="product-price">Rp <?php echo number_format($item['harga_final'], 0, ',', '.'); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-products">Tidak ada produk yang tersedia</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Real-time search functionality
        const searchInput = document.getElementById('searchInput');
        const productGrid = document.getElementById('productGrid');
        const productCards = productGrid.querySelectorAll('.product-card');

        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            
            productCards.forEach(card => {
                const productName = card.getAttribute('data-name');
                
                if (productName.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });

            // Show no results message if all cards are hidden
            const visibleCards = Array.from(productCards).filter(card => card.style.display !== 'none');
            let noResultsMsg = document.querySelector('.no-results');
            
            if (visibleCards.length === 0 && searchTerm !== '') {
                if (!noResultsMsg) {
                    noResultsMsg = document.createElement('div');
                    noResultsMsg.className = 'no-products no-results';
                    noResultsMsg.textContent = 'Produk tidak ditemukan';
                    productGrid.appendChild(noResultsMsg);
                }
            } else {
                if (noResultsMsg) {
                    noResultsMsg.remove();
                }
            }
        });

        // Sidebar navigation functionality
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', function(e) {
                // Remove active class from all items
                document.querySelectorAll('.nav-item').forEach(nav => {
                    nav.classList.remove('active');
                });
                // Add active class to clicked item
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>
