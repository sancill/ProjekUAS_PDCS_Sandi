# Folder Assets - Penyimpanan Assets Web

Folder ini digunakan untuk menyimpan semua assets web seperti icon, gambar, CSS, dan JavaScript.

## Struktur Folder

```
assets/
└── images/
    └── icons/    # Icon-icon untuk web (sidebar, button, dll)
```

## Cara Menggunakan

### Menyimpan Icon Web
Simpan icon-icon web di folder: `assets/images/icons/`

**Contoh penggunaan di HTML:**
```html
<img src="<?php echo base_url('assets/images/icons/dashboard-icon.svg'); ?>" alt="Dashboard">
```

**Contoh penggunaan di CSS:**
```css
background-image: url('../assets/images/icons/search-icon.svg');
```

## Format File yang Didukung

- **Gambar:** `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`, `.svg`, `.ico`
- **Ukuran:** Disarankan icon kecil (16x16, 24x24, 32x32, 48x48 pixels)

## Catatan

- Path menggunakan `base_url()` untuk akses dari view
- Icon disarankan dalam format SVG untuk kualitas terbaik
- Nama file menggunakan format lowercase dengan dash (contoh: `dashboard-icon.svg`)
