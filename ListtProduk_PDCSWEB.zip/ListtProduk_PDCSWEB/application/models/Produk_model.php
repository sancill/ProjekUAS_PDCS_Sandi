<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get all active products with their variants
     */
    public function get_all_produk($search = '') {
        $this->db->select('p.*');
        $this->db->from('produk p');
        $this->db->where('p.status_produk', 'aktif');
        
        if (!empty($search)) {
            $this->db->like('p.nama_produk', $search);
        }
        
        $this->db->order_by('p.created_at', 'DESC');
        
        $query = $this->db->get();
        $products = $query->result_array();
        
        // Get variants separately for each product
        foreach ($products as &$product) {
            $product['varian'] = $this->get_varian_by_produk($product['id_produk']);
            
            // Parse gambar_produk JSON
            if (!empty($product['gambar_produk'])) {
                // Try to decode as JSON first
                $gambar_data = $product['gambar_produk'];
                
                // Check if it starts with [ which indicates JSON array
                if (substr(trim($gambar_data), 0, 1) === '[') {
                    $images = json_decode($gambar_data, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($images) && !empty($images)) {
                        // It's a JSON array, get first image
                        $product['gambar'] = $images[0];
                    } else {
                        // JSON decode failed, use as is
                        $product['gambar'] = $gambar_data;
                    }
                } else {
                    // It's a plain string path
                    $product['gambar'] = $gambar_data;
                }
                
                // Normalize path: replace backslashes with forward slashes
                $product['gambar'] = str_replace('\\', '/', $product['gambar']);
                
                // Remove leading slash if exists
                $product['gambar'] = ltrim($product['gambar'], '/');
            } else {
                $product['gambar'] = '';
            }
            
            // Calculate final price
            $product['harga_final'] = $this->calculate_final_price($product);
        }
        
        return $products;
    }

    /**
     * Get variants for a specific product
     */
    public function get_varian_by_produk($id_produk) {
        $this->db->select('*');
        $this->db->from('produk_varian');
        $this->db->where('id_produk', $id_produk);
        $query = $this->db->get();
        return $query->result_array();
    }

    /**
     * Calculate final price after discount
     */
    private function calculate_final_price($product) {
        $harga_awal = floatval($product['harga_awal']);
        $harga_diskon = floatval($product['harga_diskon']);
        
        // If harga_setelah_diskon is already calculated, use it
        if (!empty($product['harga_setelah_diskon']) && floatval($product['harga_setelah_diskon']) > 0) {
            return floatval($product['harga_setelah_diskon']);
        }
        
        // Otherwise calculate it
        if ($product['tipe_diskon'] == 'persentase') {
            $diskon = ($harga_awal * $harga_diskon) / 100;
            return $harga_awal - $diskon;
        } else {
            $final = $harga_awal - $harga_diskon;
            return $final > 0 ? $final : $harga_awal;
        }
    }

    /**
     * Search products by name
     */
    public function search_produk($keyword) {
        return $this->get_all_produk($keyword);
    }
}
