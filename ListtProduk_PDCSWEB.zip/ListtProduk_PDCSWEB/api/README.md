# API Documentation

## Endpoint: Produk

### URL
```
GET /api/Produk.php
```

### Deskripsi
API untuk mengambil data produk dari database. Mendukung pencarian produk.

### Parameter (Query String)
- `search` (optional): Kata kunci untuk mencari produk berdasarkan nama

### Contoh Request

#### 1. Ambil semua produk
```
GET http://localhost/ListtProduk_PDCSWEB/api/Produk.php
```

#### 2. Cari produk
```
GET http://localhost/ListtProduk_PDCSWEB/api/Produk.php?search=xiaomi
```

### Response Format

#### Success Response
```json
{
    "status": "success",
    "message": "Daftar produk berhasil diambil",
    "data": [
        {
            "id_produk": 21,
            "nama_produk": "Xiaomi 15 Pro",
            "deskripsi_produk": "Deskripsi produk...",
            "gambar": "http://localhost/ListtProduk_PDCSWEB/uploads/produk/1765998169_dd18dc014ecfef42e5c1.jpg",
            "merek": "Xiaomi",
            "harga_awal": 12999000.00,
            "harga_diskon": 30.00,
            "tipe_diskon": "persentase",
            "harga_final": 9099300.00,
            "stok": 9,
            "sku": "Hp-001",
            "kategori": "Elektronik",
            "menu": "Smartphone",
            "varian": []
        }
    ]
}
```

#### Error Response
```json
{
    "status": "error",
    "message": "Gunakan method GET",
    "data": null
}
```

### Field Deskripsi

- **id_produk**: ID unik produk
- **nama_produk**: Nama produk
- **deskripsi_produk**: Deskripsi lengkap produk
- **gambar**: URL lengkap gambar produk (null jika tidak ada)
- **merek**: Merek produk
- **harga_awal**: Harga sebelum diskon
- **harga_diskon**: Nilai diskon
- **tipe_diskon**: Tipe diskon ("persentase" atau "nominal")
- **harga_final**: Harga setelah diskon
- **stok**: Stok produk
- **sku**: SKU produk
- **kategori**: Nama kategori
- **menu**: Nama menu
- **varian**: Array varian produk (jika ada)

### Varian Produk

Setiap varian memiliki:
- **id_varian**: ID varian
- **nama_varian**: Nama varian (contoh: "Warna", "Ukuran")
- **nilai_varian**: Nilai varian (contoh: "Merah", "XL")
- **harga_tambahan**: Harga tambahan untuk varian ini
- **stok_varian**: Stok untuk varian ini
- **gambar_varian**: URL gambar varian (null jika tidak ada)

### Catatan untuk Android Studio

1. **Base URL**: Ganti `localhost` dengan IP address komputer Anda (contoh: `192.168.1.72`)
2. **CORS**: API sudah dikonfigurasi untuk mengizinkan akses dari aplikasi Android
3. **Encoding**: Response menggunakan UTF-8 untuk mendukung karakter Indonesia
4. **Method**: Hanya menerima GET request

### Contoh Penggunaan di Android (Kotlin/Java)

```kotlin
// URL API
val url = "http://192.168.1.72/ListtProduk_PDCSWEB/api/Produk.php"

// Dengan search
val urlWithSearch = "http://192.168.1.72/ListtProduk_PDCSWEB/api/Produk.php?search=xiaomi"
```
