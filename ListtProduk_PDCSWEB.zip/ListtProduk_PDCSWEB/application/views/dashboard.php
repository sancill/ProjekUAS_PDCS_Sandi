<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f9fafb;
            color: #1f2937;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 256px;
            background: white;
            border-right: 1px solid #e5e7eb;
            box-shadow: 0px 4px 6px 0px rgba(0,0,0,0.1), 0px 10px 15px 0px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 24px;
        }

        .sidebar-header h2 {
            font-size: 20px;
            font-weight: bold;
            color: #1f2937;
            letter-spacing: -0.5px;
        }

        .sidebar-nav {
            padding: 0 24px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            margin-bottom: 8px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            color: #374151;
            transition: all 0.2s;
        }

        .nav-item:hover {
            background-color: #f3f4f6;
        }

        .nav-item.active {
            background-color: #2563eb;
            color: white;
        }

        .nav-item svg,
        .nav-item .nav-icon {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            object-fit: contain;
        }

        .nav-item span {
            font-size: 16px;
            letter-spacing: -0.5px;
        }

        /* Main Content */
        .main-content {
            margin-left: 256px;
            flex: 1;
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: white;
            border-bottom: 1px solid #e5e7eb;
            box-shadow: 0px 1px 2px 0px rgba(0,0,0,0.05);
            padding: 16px 32px;
            height: 75px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .header-title {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            letter-spacing: -0.5px;
        }

        /* Content Area */
        .content-area {
            padding: 32px;
        }

        .dashboard-content {
            background: white;
            border-radius: 8px;
            padding: 40px;
            box-shadow: 0px 1px 2px 0px rgba(0,0,0,0.05);
        }

        .dashboard-content h1 {
            font-size: 32px;
            font-weight: bold;
            color: #1f2937;
            letter-spacing: -0.5px;
            margin-bottom: 16px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Menu</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="<?php echo base_url('listproduk/dashboard'); ?>" class="nav-item active">
                    <img src="<?php echo base_url('assets/images/icons/home.png'); ?>" alt="Dashboard" class="nav-icon" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <svg viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:none;">
                        <path d="M1 9L9 1L17 9M1 9L9 17L17 9M1 9H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo base_url('listproduk'); ?>" class="nav-item">
                    <img src="<?php echo base_url('assets/images/icons/clipboard.png'); ?>" alt="List Produk" class="nav-icon" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <svg viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:none;">
                        <path d="M1 1H15M1 5H15M1 9H15M1 13H15M1 17H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                    <span>List Produk</span>
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1 class="header-title">Dashboard</h1>
            </div>

            <!-- Content Area -->
            <div class="content-area">
                <div class="dashboard-content">
                    <h1>Halaman Dashboard List Produk</h1>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
