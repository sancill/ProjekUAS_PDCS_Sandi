<?php
// Set header untuk JSON dan CORS (agar bisa diakses dari Android)
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../includes/config.php';

// Fungsi untuk response JSON
function response($status, $msg, $data = null) {
    echo json_encode([
        'status' => $status,
        'message' => $msg,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Pastikan method yang digunakan adalah GET
if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    response("error", "Gunakan method GET");
}

// Ambil parameter search jika ada
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';

// Query untuk mengambil data produk
$query = "SELECT 
    p.id_produk,
    p.nama_produk,
    p.deskripsi_produk,
    p.gambar_produk,
    p.merek,
    p.harga_awal,
    p.harga_diskon,
    p.tipe_diskon,
    p.harga_setelah_diskon,
    p.stok,
    p.sku,
    k.nama_kategori,
    m.nama_menu
FROM produk p
LEFT JOIN kategori k ON p.id_kategori = k.id_kategori
LEFT JOIN menu m ON p.id_menu = m.id_menu
WHERE p.status_produk = 'aktif'";

// Tambahkan filter search jika ada
if (!empty($search)) {
    $query .= " AND p.nama_produk LIKE '%$search%'";
}

$query .= " ORDER BY p.created_at DESC";

$result = mysqli_query($koneksi, $query);

if (!$result) {
    response("error", "Query gagal: " . mysqli_error($koneksi));
}

// Inisialisasi array untuk menyimpan data produk
$daftar = [];

// Ambil base URL untuk gambar
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '192.168.1.72';
$script_path = dirname(dirname($_SERVER['SCRIPT_NAME']));
$base_url = $protocol . '://' . $host . $script_path . '/';

while ($row = mysqli_fetch_assoc($result)) {
    // Parse gambar_produk (bisa JSON array atau string)
    $gambar = '';
    if (!empty($row['gambar_produk'])) {
        $gambar_data = $row['gambar_produk'];
        
        // Cek jika JSON array
        if (substr(trim($gambar_data), 0, 1) === '[') {
            $images = json_decode($gambar_data, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($images) && !empty($images)) {
                $gambar = $images[0];
            } else {
                $gambar = $gambar_data;
            }
        } else {
            $gambar = $gambar_data;
        }
        
        // Normalize path
        $gambar = str_replace('\\', '/', $gambar);
        $gambar = ltrim($gambar, '/');
    }
    
    // Hitung harga final
    $harga_final = 0;
    if (!empty($row['harga_setelah_diskon']) && floatval($row['harga_setelah_diskon']) > 0) {
        $harga_final = floatval($row['harga_setelah_diskon']);
    } else {
        $harga_awal = floatval($row['harga_awal']);
        $harga_diskon = floatval($row['harga_diskon']);
        
        if ($row['tipe_diskon'] == 'persentase') {
            $diskon = ($harga_awal * $harga_diskon) / 100;
            $harga_final = $harga_awal - $diskon;
        } else {
            $harga_final = $harga_awal - $harga_diskon;
        }
    }
    
    // Ambil varian produk
    $varian = [];
    $varian_query = "SELECT 
        id_varian,
        nama_varian,
        nilai_varian,
        harga_tambahan,
        stok_varian,
        gambar_varian
    FROM produk_varian 
    WHERE id_produk = " . intval($row['id_produk']);
    
    $varian_result = mysqli_query($koneksi, $varian_query);
    if ($varian_result) {
        while ($varian_row = mysqli_fetch_assoc($varian_result)) {
            $varian_gambar = '';
            if (!empty($varian_row['gambar_varian'])) {
                $varian_gambar_data = $varian_row['gambar_varian'];
                if (substr(trim($varian_gambar_data), 0, 1) === '[') {
                    $varian_images = json_decode($varian_gambar_data, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($varian_images) && !empty($varian_images)) {
                        $varian_gambar = $varian_images[0];
                    }
                } else {
                    $varian_gambar = $varian_gambar_data;
                }
                $varian_gambar = str_replace('\\', '/', $varian_gambar);
                $varian_gambar = ltrim($varian_gambar, '/');
            }
            
            $varian[] = [
                "id_varian" => intval($varian_row['id_varian']),
                "nama_varian" => $varian_row['nama_varian'],
                "nilai_varian" => $varian_row['nilai_varian'],
                "harga_tambahan" => floatval($varian_row['harga_tambahan']),
                "stok_varian" => intval($varian_row['stok_varian']),
                "gambar_varian" => !empty($varian_gambar) ? $base_url . $varian_gambar : null
            ];
        }
    }
    
    // Format data produk
    $daftar[] = [
        "id_produk" => intval($row['id_produk']),
        "nama_produk" => $row['nama_produk'],
        "deskripsi_produk" => $row['deskripsi_produk'],
        "gambar" => !empty($gambar) ? $base_url . $gambar : null,
        "merek" => $row['merek'],
        "harga_awal" => floatval($row['harga_awal']),
        "harga_diskon" => floatval($row['harga_diskon']),
        "tipe_diskon" => $row['tipe_diskon'],
        "harga_final" => $harga_final,
        "stok" => intval($row['stok']),
        "sku" => $row['sku'],
        "kategori" => $row['nama_kategori'],
        "menu" => $row['nama_menu'],
        "varian" => $varian
    ];
}

// Kirim response
response("success", "Daftar produk berhasil diambil", $daftar);
?>
